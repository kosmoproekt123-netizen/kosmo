package com.quizmaster.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
